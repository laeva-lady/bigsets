# Bigsets
regroups stuff i use often in Typst



---

part of the lib is based on [Tinyset by SylvanFranklin](https://github.com/SylvanFranklin/tinyset)
